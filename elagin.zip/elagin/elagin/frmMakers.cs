﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace elagin
{
    public partial class frmMakers : Form
    {
        private frmTableca frmTableca;
        public frmMakers()
        {
            InitializeComponent();
        }

        private void productBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.st11DataSet);

        }

        private void frmMakers_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st11DataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.st11DataSet.Product);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmTableca = new frmTableca();
            frmTableca.ShowDialog();
        }
    }
}
