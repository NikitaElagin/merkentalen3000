﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace elagin
{
    public partial class Form1 : Form
    {
        private frmDesktop frmDesktop;
        private frmLaptop frmLaptop;
        private frmPrinter frmPrinter;
        private frmMakers frmMakers;
        private frmTableca frmTableca;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmDesktop = new frmDesktop();
        
            frmDesktop.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmLaptop = new frmLaptop();
         
            frmLaptop.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmPrinter = new frmPrinter();

            frmPrinter.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmMakers = new frmMakers();
            frmMakers.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
